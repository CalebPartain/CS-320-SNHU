import java.util.HashMap;
import java.util.Map;

public class ContactService {

    private final Map<String, Contact> contacts = new HashMap<>();

    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getId())) {
            throw new IllegalArgumentException("Contact with the same ID already exists.");
        }
        contacts.put(contact.getId(), contact);
    }

    public void deleteContact(String id) {
        if (!contacts.containsKey(id)) {
            throw new IllegalArgumentException("Contact with ID " + id + " does not exist.");
        }
        contacts.remove(id);
    }

    public void updateContact(String id, String firstName, String lastName, String number, String address) {
        if (!contacts.containsKey(id)) {
            throw new IllegalArgumentException("Contact with ID " + id + " does not exist.");
        }
        Contact contact = contacts.get(id);
        if (firstName != null) {
            contact.setFirstName(firstName);
        }
        if (lastName != null) {
            contact.setLastName(lastName);
        }
        if (number != null) {
            contact.setNumber(number);
        }
        if (address != null) {
            contact.setAddress(address);
        }
    }
    
    public Contact getContact(String id) {
        if (!contacts.containsKey(id)) {
            throw new IllegalArgumentException("Contact with ID " + id + " does not exist.");
        }
        return contacts.get(id);
    }

    public Map<String, Contact> getContacts() {
        return new HashMap<>(contacts);
    }
}
