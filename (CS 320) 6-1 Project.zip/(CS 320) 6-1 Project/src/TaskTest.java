import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TaskTest {
    private Task task;

    @Before
    public void setUp() {
        task = new Task("1", "Task1", "This is a test task 1");
    }

    @Test
    public void testGetTaskId() {
        assertEquals("1", task.getId());
    }

    @Test
    public void testGetFirstName() {
        assertEquals("Task1", task.getName());
    }

    @Test
    public void testGetLastName() {
        assertEquals("This is a test task 1", task.getDescription());
    }
    
    @Test
    public void testNullId() {
    	Throwable exception = assertThrows(NullPointerException.class, () -> {
    		Task task2 = new Task(null, "Task1", "This is a test task 1");
        });
    	assertEquals("Invalid Task ID", exception.getMessage());
    }
    
    @Test
    public void testNullName() {
    	Throwable exception = assertThrows(NullPointerException.class, () -> {
            task.setName(null); 
        });
    	assertEquals("First name cannot be null or longer than 10 characters", exception.getMessage());
    }
    
    @Test
    public void testNullDescription() {
    	Throwable exception = assertThrows(NullPointerException.class, () -> {
            task.setDescription(null); 
        });
    	assertEquals("Last name cannot be null or longer than 10 characters", exception.getMessage());
    }
   
}
	