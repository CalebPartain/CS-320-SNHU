import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Tag;

import java.util.Date;
import java.util.Map;


public class AppointmentServiceTest {

    private AppointmentService AppointmentService;

    @BeforeEach
    public void setUp() {
        AppointmentService = new AppointmentService();
    }

    @Tag("AddAppointment")
    @RepeatedTest(3)
    public void testAddAppointment() {
        Appointment appointment1 = new Appointment("1", new Date(), "This is a test appointment 1");
        AppointmentService.addAppointment(appointment1);
        Map<String, Appointment> appointments = AppointmentService.getAppointments();
        Assertions.assertEquals(1, appointments.size());
        Assertions.assertEquals(appointment1, appointments.get("1"));
    }

    @Tag("AddDuplicateAppointment")
    @RepeatedTest(3)
    public void testAddDuplicateAppointment() {
    	Appointment appointment1 = new Appointment("1", new Date(), "This is a test appointment 1");
    	AppointmentService.addAppointment(appointment1);
        Throwable exception = Assertions.assertThrows(IllegalArgumentException.class, () -> {
            Appointment appointment2 = new Appointment("1", new Date(), "This is a test appointment 2");
            AppointmentService.addAppointment(appointment2);
        });
        Assertions.assertEquals("Appointment with the same ID already exists.", exception.getMessage());
    }

    @Tag("DeleteAppointment")
    @RepeatedTest(3)
    public void testDeleteAppointment() {
    	Appointment appointment1 = new Appointment("1", new Date(), "This is a test appointment 1");
    	Appointment appointment2 = new Appointment("2", new Date(), "This is a test appointment 2");
    	AppointmentService.addAppointment(appointment1);
    	AppointmentService.addAppointment(appointment2);
        AppointmentService.deleteAppointment("1");
        Map<String, Appointment> appointments = AppointmentService.getAppointments();
        Assertions.assertEquals(1, appointments.size());
        Assertions.assertNull(appointments.get("1"));
        Assertions.assertEquals(appointment2, appointments.get("2"));
    }

    @Tag("DeleteNonexistent")
    @RepeatedTest(3)
    public void testDeleteNonexistentAppointment() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            AppointmentService.deleteAppointment("1");
        });
    }

    @Tag("UpdateAppointment")
    @RepeatedTest(3)
    public void testUpdateAppointment() {
    	Appointment appointment1 = new Appointment("1", new Date(), "This is a test appointment 1");
        AppointmentService.addAppointment(appointment1);
        AppointmentService.updateAppointment("1", new Date(), "This is a test appointment 2");
        Map<String, Appointment> appointments = AppointmentService.getAppointments();
        Assertions.assertEquals(new Date(), appointments.get("1").getDate());
        Assertions.assertEquals("This is a test appointment 2", appointments.get("1").getDescription());
    }

    @Tag("UpdateAppointment")
    @RepeatedTest(3)
    public void testUpdateNonexistentAppointment() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            AppointmentService.updateAppointment("1", new Date(), "This is a test appointment 2");
        });
    }
    
    @Tag("UpdateAppointment")
    @RepeatedTest(3)
    public void testGetNonexistentAppointment() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            AppointmentService.getAppointment("1");
        });
    }
}
