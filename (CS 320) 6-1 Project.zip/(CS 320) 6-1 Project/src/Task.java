
public class Task {
	private final String id;
	private String name;
	private String description;
	
	
	
	 public Task(String id, String name, String description) {
	        if (id == null || id.length() > 10) {
	            throw new NullPointerException("Invalid Task ID");
	        }
	        if (name == null || name.length() > 20) {
	            throw new NullPointerException("First name cannot be null or longer than 10 characters");
	        }
	        if (description == null || description.length() > 50) {
	            throw new NullPointerException("Last name cannot be null or longer than 10 characters");
	        }
	        this.id = id;
	        this.name = name;
	        this.description = description;
	 }
	 
	 public String getId() {
		 return id;
	 }
	 
	 public String getName() {
		 return name;
	 }
	 
	 public void setName(String name) {
		 if (name == null || name.length() > 20) {
	            throw new NullPointerException("First name cannot be null or longer than 10 characters");
	        }
		 this.name = name;
	 }
	 
	 public String getDescription() {
		 return description;
	 }
	 
	 public void setDescription(String description) {
		 if (description == null || description.length() > 50) {
	            throw new NullPointerException("Last name cannot be null or longer than 10 characters");
	        }
		 this.description = description;
	 }
}
	
