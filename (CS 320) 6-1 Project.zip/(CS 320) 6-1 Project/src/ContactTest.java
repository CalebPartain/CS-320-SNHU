import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ContactTest {
    private Contact contact;

    @Before
    public void setUp() {
        contact = new Contact("C000000001", "John", "Doe", "1234567890", "123 Main St");
    }

    @Test
    public void testGetContactId() {
        assertEquals("C000000001", contact.getId());
    }

    @Test
    public void testGetFirstName() {
        assertEquals("John", contact.getFirstName());
    }

    @Test
    public void testGetLastName() {
        assertEquals("Doe", contact.getLastName());
    }

    @Test
    public void testGetPhone() {
        assertEquals("1234567890", contact.getNumber());
    }

    @Test
    public void testGetAddress() {
        assertEquals("123 Main St", contact.getAddress());
    }

    @Test(expected = NullPointerException.class)
    public void testSetNullFirstName() {
        contact.setFirstName(null);
    }

    @Test(expected = NullPointerException.class)
    public void testSetNullLastName() {
        contact.setLastName(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSetInvalidPhone() {
        contact.setNumber("123456789");
    }

    @Test(expected = NullPointerException.class)
    public void testSetNullAddress() {
        contact.setAddress(null);
    }
}
	