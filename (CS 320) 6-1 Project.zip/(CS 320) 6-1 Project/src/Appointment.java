import java.util.Date;

public class Appointment {
	private final String id;
	private Date date;
	private String description;
	
	
	
	 public Appointment(String id, Date date, String description) {
	        if (id == null || id.length() > 10) {
	            throw new NullPointerException("Invalid appointment ID");
	        }
	        if (date == null || date.before(new Date())) {
	            throw new NullPointerException("Appointment date cannot be null before current date.");
	        }
	        if (description == null || description.length() > 50) {
	            throw new NullPointerException("Descirption cannot be null or longer thant 50 characters.");
	        }
	        this.id = id;
	        this.date = date;
	        this.description = description;
	 }
	 
	 public String getId() {
		 return id;
	 }
	 
	 public Date getDate() {
		 return date;
	 }
	 
	 public void setDate(Date date) {
		 if (date == null || date.before(new Date())) {
	            throw new NullPointerException("Appointment date cannot be null or before current date.");
	        }
		 this.date = date;
	 }
	 
	 public String getDescription() {
		 return description;
	 }
	 
	 public void setDescription(String description) {
		 if (description == null || description.length() > 50) {
	            throw new NullPointerException("Descirption cannot be null or longer thant 50 characters.");
	        }
		 this.description = description;
	 }
}
	
