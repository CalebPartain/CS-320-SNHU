import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

public class AppointmentTest {
    private Appointment appointment;

    @Before
    public void setUp() {
        appointment = new Appointment("1", new Date(), "This is a test appointment 1");
    }

    @Test
    public void testGetappointmentId() {
        assertEquals("1", appointment.getId());
    }

    @Test
    public void testGetDate() {
        assertEquals(new Date(), appointment.getDate());
    }

    @Test
    public void testGetDescription() {
        assertEquals("This is a test appointment 1" , appointment.getDescription());
    }

    @Test
    public void testNullId() {
    	Throwable exception = assertThrows(NullPointerException.class, () -> {
    		Appointment Appointment2 = new Appointment(null, new Date(), "This is a test task 1");
        });
    	assertEquals("Invalid appointment ID", exception.getMessage());
    }
    
    @Test
    public void testNullDescription() {
    	Throwable exception = assertThrows(NullPointerException.class, () -> {
            appointment.setDescription(null); 
        });
    	assertEquals("Descirption cannot be null or longer thant 50 characters.", exception.getMessage());
    }
    
    @Test
    public void testNullDate() {
    	Throwable exception = assertThrows(NullPointerException.class, () -> {
            appointment.setDate(null); 
        });
    	assertEquals("Appointment date cannot be null or before current date.", exception.getMessage());
    }
}
	