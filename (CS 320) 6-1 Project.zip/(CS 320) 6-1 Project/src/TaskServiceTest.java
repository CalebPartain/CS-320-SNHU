import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Tag;
import java.util.Map;


public class TaskServiceTest {

    private TaskService TaskService;

    @BeforeEach
    public void setUp() {
        TaskService = new TaskService();
    }

    @Tag("AddTask")
    @RepeatedTest(3)
    public void testAddTask() {
        Task task1 = new Task("1", "Task1", "This is a test task 1");
        TaskService.addTask(task1);
        Map<String, Task> tasks = TaskService.getTasks();
        Assertions.assertEquals(1, tasks.size());
        Assertions.assertEquals(task1, tasks.get("1"));
    }

    @Tag("AddDuplicateTask")
    @RepeatedTest(3)
    public void testAddDuplicateTask() {
    	Task task1 = new Task("1", "Task1", "This is a test task 1");
    	TaskService.addTask(task1);
        Throwable exception = Assertions.assertThrows(IllegalArgumentException.class, () -> {
            Task task2 = new Task("1", "Task2", "This is a test task 2");
            TaskService.addTask(task2);
        });
        Assertions.assertEquals("Task with the same ID already exists.", exception.getMessage());
    }

    @Tag("DeleteTask")
    @RepeatedTest(3)
    public void testDeleteTask() {
    	Task task1 = new Task("1", "Task1", "This is a test task 1");
    	Task task2 = new Task("2", "Task2", "This is a test task 2");
    	TaskService.addTask(task1);
    	TaskService.addTask(task2);
        TaskService.deleteTask("1");
        Map<String, Task> tasks = TaskService.getTasks();
        Assertions.assertEquals(1, tasks.size());
        Assertions.assertNull(tasks.get("1"));
        Assertions.assertEquals(task2, tasks.get("2"));
    }

    @Tag("DeleteNonexistent")
    @RepeatedTest(3)
    public void testDeleteNonexistentTask() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            TaskService.deleteTask("1");
        });
    }

    @Tag("UpdateTask")
    @RepeatedTest(3)
    public void testUpdateTask() {
    	Task task1 = new Task("1", "Task1", "This is a test task 1");
        TaskService.addTask(task1);
        TaskService.updateTask("1", "Task2", "This is a test task 2");
        Map<String, Task> tasks = TaskService.getTasks();
        Assertions.assertEquals("Task2", tasks.get("1").getName());
        Assertions.assertEquals("This is a test task 2", tasks.get("1").getDescription());
    }

    @Tag("UpdateTask")
    @RepeatedTest(3)
    public void testUpdateNonexistentTask() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            TaskService.updateTask("1", "Task2", "This is a test task 2");
        });
    }
    
    @Tag("UpdateAppointment")
    @RepeatedTest(3)
    public void testGetNonexistentAppointment() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            TaskService.getTask("1");
        });
    }
}
