import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Map;

public class ContactServiceTest {

    private ContactService contactService;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
    }

    @Test
    public void testAddContact() {
        Contact contact1 = new Contact("1", "Caleb", "Partain", "1234567891", "123 SNHU Ln");
        contactService.addContact(contact1);
        Map<String, Contact> contacts = contactService.getContacts();
        Assertions.assertEquals(1, contacts.size());
        Assertions.assertEquals(contact1, contacts.get("1"));
    }

    @Test
    public void testAddDuplicateContact() {
        Contact contact1 = new Contact("1", "Caleb", "Partain", "1234567891", "123 SNHU Ln");
        contactService.addContact(contact1);
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            Contact contact2 = new Contact("1", "Allissa", "Partain", "1234567891", "123 SNHU Ln");
            contactService.addContact(contact2);
        });
    }

    @Test
    public void testDeleteContact() {
        Contact contact1 = new Contact("1", "Caleb", "Partain", "1234567891", "123 SNHU Ln");
        Contact contact2 = new Contact("2", "Allissa", "Partain", "1234567891", "123 SNHU Ln");
        contactService.addContact(contact1);
        contactService.addContact(contact2);
        contactService.deleteContact("1");
        Map<String, Contact> contacts = contactService.getContacts();
        Assertions.assertEquals(1, contacts.size());
        Assertions.assertNull(contacts.get("1"));
        Assertions.assertEquals(contact2, contacts.get("2"));
    }

    @Test
    public void testDeleteNonexistentContact() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contactService.deleteContact("1");
        });
    }

    @Test
    public void testUpdateContact() {
        Contact contact1 = new Contact("1", "Caleb", "Partain", "1234567891", "123 SNHU Ln");
        contactService.addContact(contact1);
        contactService.updateContact("1", "Allissa", "Partain", "1234567891", "123 SNHU Ln");
        Map<String, Contact> contacts = contactService.getContacts();
        Assertions.assertEquals("Allissa", contacts.get("1").getFirstName());
        Assertions.assertEquals("Partain", contacts.get("1").getLastName());
        Assertions.assertEquals("1234567891", contacts.get("1").getNumber());
        Assertions.assertEquals("123 SNHU Ln", contacts.get("1").getAddress());
    }

    @Test
    public void testUpdateNonexistentContact() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContact("1", "Allissa", "Partain", "1234567891", "123 SNHU Ln");
        });
    }
}
