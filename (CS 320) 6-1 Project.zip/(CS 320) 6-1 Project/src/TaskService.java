import java.util.HashMap;
import java.util.Map;

public class TaskService {

	private final Map<String, Task> tasks = new HashMap<>();
	
	public String addTask(Task task) {
        if (tasks.containsKey(task.getId())) {
            throw new IllegalArgumentException("Task with the same ID already exists.");
        }
        tasks.put(task.getId(), task);
        return(task.getId());
    }
	
	public void deleteTask(String id) {
        if (!tasks.containsKey(id)) {
            throw new IllegalArgumentException("Task with ID " + id + " does not exist.");
        }
        tasks.remove(id);
    }
	
	public void updateTask(String id, String name, String description) {
        if (!tasks.containsKey(id)) {
            throw new IllegalArgumentException("Task with ID " + id + " does not exist.");
        }
        Task task = tasks.get(id);
        if (name != null) {
            task.setName(name);
        }
        if (description != null) {
            task.setDescription(description);
        }
    }
	
	public Task getTask(String id) {
        if (!tasks.containsKey(id)) {
            throw new IllegalArgumentException("Task with ID " + id + " does not exist.");
        }
        return tasks.get(id);
    }

    public Map<String, Task> getTasks() {
        return new HashMap<>(tasks);
    }
}
