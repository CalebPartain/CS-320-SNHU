import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class AppointmentService {

	private final Map<String, Appointment> appointments = new HashMap<>();
	
	public String addAppointment(Appointment appointment) {
        if (appointments.containsKey(appointment.getId())) {
            throw new IllegalArgumentException("Appointment with the same ID already exists.");
        }
        appointments.put(appointment.getId(), appointment);
        return(appointment.getId());
    }
	
	public void deleteAppointment(String id) {
        if (!appointments.containsKey(id)) {
            throw new IllegalArgumentException("Appointment with ID " + id + " does not exist.");
        }
        appointments.remove(id);
    }
	
	public void updateAppointment(String id, Date date, String description) {
        if (!appointments.containsKey(id)) {
            throw new IllegalArgumentException("Appointment with ID " + id + " does not exist.");
        }
        Appointment appointment = appointments.get(id);
        if (date != null) {
            appointment.setDate(date);
        }
        if (description != null) {
            appointment.setDescription(description);
        }
    }
	
	public Appointment getAppointment(String id) {
        if (!appointments.containsKey(id)) {
            throw new IllegalArgumentException("appointment with ID " + id + " does not exist.");
        }
        return appointments.get(id);
    }

    public Map<String, Appointment> getAppointments() {
        return new HashMap<>(appointments);
    }
}
